﻿using System.Windows;
using System.Windows.Controls;

namespace Final
{
    public partial class BankAccountPage : Page
    {
        public BankAccountPage()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text;
            string iban = IbanTextBox.Text;
            string bic = BicTextBox.Text;
            string bank = BankNameTextBox.Text;

            // Placeholder action - you could save this to file, DB, etc.
            MessageBox.Show($"Saved:\n\nName: {name}\nIBAN: {iban}\nBIC: {bic}\nBank: {bank}",
                "Bank Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
