﻿using Microsoft.Win32;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace Final
{
    public partial class UploadDocumentPage : Page
    {
        private string baseFolder = Path.Combine(Directory.GetCurrentDirectory(), "DocumentsStorage");

        public UploadDocumentPage()
        {
            InitializeComponent();
            InitializeFolders();
        }

        private void InitializeFolders()
        {
            if (!Directory.Exists(baseFolder))
                Directory.CreateDirectory(baseFolder);

            FolderComboBox.Items.Clear();
            var folders = Directory.GetDirectories(baseFolder);
            foreach (var folder in folders)
            {
                FolderComboBox.Items.Add(System.IO.Path.GetFileName(folder));
            }

            if (FolderComboBox.Items.Count > 0)
                FolderComboBox.SelectedIndex = 0;

            RefreshFileList();
        }

        private void NewFolder_Click(object sender, RoutedEventArgs e)
        {
            string folderName = Microsoft.VisualBasic.Interaction.InputBox("Enter new folder name:", "New Folder", "MyFolder");
            if (!string.IsNullOrWhiteSpace(folderName))
            {
                string newFolderPath = Path.Combine(baseFolder, folderName);
                if (!Directory.Exists(newFolderPath))
                {
                    Directory.CreateDirectory(newFolderPath);
                    FolderComboBox.Items.Add(folderName);
                    FolderComboBox.SelectedItem = folderName;
                }
            }
        }

        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            if (FolderComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a folder first.");
                return;
            }

            var dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            if (dialog.ShowDialog() == true)
            {
                string targetFolder = Path.Combine(baseFolder, FolderComboBox.SelectedItem.ToString());

                foreach (var file in dialog.FileNames)
                {
                    string fileName = System.IO.Path.GetFileName(file);
                    string destFile = Path.Combine(targetFolder, fileName);
                    File.Copy(file, destFile, true);
                }

                RefreshFileList();
            }
        }

        private void RefreshFileList()
        {
            FileListView.Items.Clear();

            if (FolderComboBox.SelectedItem == null) return;

            string folderPath = Path.Combine(baseFolder, FolderComboBox.SelectedItem.ToString());
            if (Directory.Exists(folderPath))
            {
                var files = Directory.GetFiles(folderPath);
                foreach (var file in files)
                {
                    FileListView.Items.Add(System.IO.Path.GetFileName(file));
                }
            }
        }

        private void FolderComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshFileList();
        }
    }
}
