﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Final
{
    public partial class Main : Window
    {
        // Fake user database (for testing)
        private Dictionary<string, string> users = new Dictionary<string, string>();
        private string currentEmail = "";
        private string currentPassword = "";
        private string currentVerificationCode = "";
        private bool isSignUpProcess = false;

        public Main()
        {
            InitializeComponent();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                StatusTextBlock.Text = "Please enter both email and password.";
                return;
            }

            if (!users.ContainsKey(email) || users[email] != password)
            {
                StatusTextBlock.Text = "Invalid credentials.";
                return;
            }

            currentEmail = email;
            currentPassword = password;
            isSignUpProcess = false;

            Start2FA();
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                StatusTextBlock.Text = "Please fill out both fields.";
                return;
            }

            if (users.ContainsKey(email))
            {
                StatusTextBlock.Text = "This email is already registered.";
                return;
            }

            currentEmail = email;
            currentPassword = password;
            isSignUpProcess = true;

            Start2FA();
        }

        private void Start2FA()
        {
            // Generate a 6-digit code
            Random rand = new Random();
            currentVerificationCode = rand.Next(100000, 999999).ToString();

            // Show it as a simulated "email" or "SMS"
            MessageBox.Show($"Your verification code is: {currentVerificationCode}", "2FA Verification");

            // Ask user to input it
            string inputCode = Microsoft.VisualBasic.Interaction.InputBox("Enter the verification code sent to you:", "2FA");

            if (inputCode == currentVerificationCode)
            {
                if (isSignUpProcess)
                {
                    users.Add(currentEmail, currentPassword);
                    StatusTextBlock.Text = "Sign-up successful!";
                }
                else
                {
                    StatusTextBlock.Text = "Logged in successfully!";
                }
            }
            else
            {
                StatusTextBlock.Text = "Incorrect verification code.";
            }
        }
    }
}
