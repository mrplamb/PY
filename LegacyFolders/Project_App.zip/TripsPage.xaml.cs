﻿using System.Windows;
using System.Windows.Controls;

namespace Final
{
    public partial class TripsPage : Page
    {
        public TripsPage()
        {
            InitializeComponent();
        }

        private void AddNewTrip_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Add New Trip clicked!");
            // You can navigate to a 'NewTripPage' or open a modal here later
        }
    }
}
