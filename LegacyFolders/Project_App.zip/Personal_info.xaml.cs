﻿using System.Windows;
using System.Windows.Controls;

namespace Final
{
    public partial class PersonalInfoPage : Page
    {
        public PersonalInfoPage()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string name = FullNameTextBox.Text;
            string dob = DobDatePicker.SelectedDate?.ToShortDateString() ?? "Not Selected";
            string gender = (GenderComboBox.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Not Selected";
            string email = EmailTextBox.Text;
            string phone = PhoneTextBox.Text;
            string address = AddressTextBox.Text;

            // Placeholder for saving or validation
            MessageBox.Show($"Saved Personal Info:\n\nName: {name}\nDOB: {dob}\nGender: {gender}\nEmail: {email}\nPhone: {phone}\nAddress: {address}",
                "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
