using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolidayManagerWeb.Views.Trip
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
