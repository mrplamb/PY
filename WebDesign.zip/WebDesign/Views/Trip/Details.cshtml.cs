using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolidayManagerWeb.Views.Trip
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
