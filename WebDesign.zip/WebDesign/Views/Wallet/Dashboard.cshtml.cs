using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolidayManagerWeb.Views.Wallet
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
